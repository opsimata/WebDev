<?php

$username = $_POST["username"];
$password = $_POST["password"];

echo "O usuário {$username} está tentando logar com a senha {$password}";

$nota1 = 4;
$nota2 = 8;

$media = ($nota1 + $nota2)/2;

echo "média das notas: {$media}";